<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            {{$title}}({{$count}})
        </h3>
    </div>
    <div class="card-body">
        @include($data)
    </div>
</div>