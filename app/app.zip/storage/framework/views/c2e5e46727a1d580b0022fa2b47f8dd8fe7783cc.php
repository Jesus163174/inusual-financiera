<div class="card">
    <div class="card-header">
        <h3 class="card-title">
            <?php echo e($title); ?>(<?php echo e($count); ?>)
        </h3>
    </div>
    <div class="card-body">
        <?php echo $__env->make($data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/layouts/card.blade.php ENDPATH**/ ?>