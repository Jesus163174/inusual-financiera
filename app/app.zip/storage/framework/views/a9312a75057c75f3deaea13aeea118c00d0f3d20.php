<?php $__env->startSection('title','Actualizar Cobrador'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mg-top-md">
        <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Actualizar empleado</h3>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(asset('admin/cobradores/'.$employe->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('put'); ?>
                        <?php echo $__env->make('employees.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/employees/edit.blade.php ENDPATH**/ ?>