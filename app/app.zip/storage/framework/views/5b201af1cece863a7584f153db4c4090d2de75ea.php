<?php $__env->startSection('title','Detalle de usuario'); ?>
<?php $__env->startSection('content'); ?>
<div class="row top-md">
    <div class="col-lg-4">
        <div class="card card-small mb-4 pt-3">
            <div class="card-header border-bottom text-center">
                <div class="mb-3 mx-auto">
                    <img class="rounded-circle" src="<?php echo e(asset('images/avatars/1.jpg')); ?>" alt="User Avatar" width="110"> </div>
                <h4 class="mb-0"><?php echo e($user->name); ?></h4>
                <span class="text-muted d-block mb-2"><?php echo e($user->status); ?></span>
                <button type="button" class="mb-2 btn btn-sm btn-pill btn-outline-success mr-2">
                    <i class="material-icons mr-1">money</i>Historial</button>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item px-4">
                    <div class="progress-wrapper">
                        <form action="<?php echo e(asset('admin/usuarios/'.$user->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <?php if($user->status == 'activo'): ?>
                                <button type="submit" class="mb-2 btn btn-sm btn-pill btn-outline-danger mr-2">Dar de baja</button>
                            <?php else: ?>
                                <button class="mb-2 btn btn-sm btn-pill btn-outline-success mr-2">Dar de alta</button>
                            <?php endif; ?>
                        </form>
                    </div>
                </li>
               
            </ul>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card card-small mb-4">
            <div class="card-header border-bottom">
                <h6 class="m-0">Detalle de la cuenta</h6>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item p-3">
                    <div class="row">
                        <div class="col">
                            <form action="<?php echo e(asset('admin/usuarios/'.$user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo e(method_field('put')); ?>

                                <div class="form-row">
                                    <div class="form-group col-md-6">
                                        <label for="feFirstName">Nombre</label>
                                        <input type="text" required name="name" class="form-control" id="feFirstName"
                                            placeholder="First Name" value="<?php echo e($user->name); ?>"> </div>
                                    <div class="form-group col-md-6">
                                        <label for="feLastName">Email</label>
                                        <input type="email" required name="email" class="form-control" id="feLastName" placeholder="Last Name"
                                            value="<?php echo e($user->email); ?>"> 
                                    </div>
                                    
                                    <div class="form-group col-md-6">
                                        <label for="feLastName">Rol</label>
                                        <select name="rol" id="" class="form-control">
                                            <option value="<?php echo e($user->rol); ?>" selecte><?php echo e($user->rol); ?></option>
                                            <option value="admin">1.Administrador</option>
                                            <option value="cobrador">2.Cobrador</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <button class="mb-2 btn btn-sm btn-pill btn-outline-success mr-2">Actualizar</button>
                                    </div>
                                    
                                </div>
                               
                            </form>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/users/show.blade.php ENDPATH**/ ?>