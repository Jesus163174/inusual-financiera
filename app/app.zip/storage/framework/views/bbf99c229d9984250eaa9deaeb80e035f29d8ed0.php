<table id="table" class="table table-bordered">
    <thead>
        <tr>
            <th class="text-center">Nombre</th>
            <th class="text-center">Email</th>
            <th class="text-center">Estatus</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center">
                    <a href="<?php echo e(asset('/admin/usuarios/'.$employe->id)); ?>"><?php echo e($employe->name); ?></a>
                </td>
                <td class="text-center"><?php echo e($employe->email); ?></td>
                <td class="text-center"><?php echo e($employe->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/users/data.blade.php ENDPATH**/ ?>